#!/usr/bin/env python3
"""
Test script for X.com social media integration
"""

import sys
import os
import asyncio
import logging
import pytest
from datetime import datetime

# Add the project root to the path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from search.manager import SearchManager
from search.social.x_trending import XTrendingDetector
from search.social.x_analyzer import XTrendingAnalyzer

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

@pytest.mark.asyncio
async def test_x_trending_detector():
    """Test X.com trending detector"""
    print("🧪 Testing X.com Trending Detector...")

    try:
        detector = XTrendingDetector()

        # Test trending topics detection
        print("📊 Getting trending topics...")
        trending_topics = detector.get_trending_topics()
        print(f"Found {len(trending_topics)} trending topics")

        for topic in trending_topics[:5]:  # Show top 5
            print(f"  • {topic.topic} - {topic.tweet_count} tweets - {topic.category}")

        # Test coding trends search
        print("\n🔍 Searching for AI coding trends...")
        coding_trends = detector.search_coding_trends("AI coding")
        print(f"Found {len(coding_trends)} AI coding trends")

        for trend in coding_trends[:5]:  # Show top 5
            print(f"  • {trend.topic} - Score: {trend.engagement_score:.2f}")

        return True

    except Exception as e:
        print(f"❌ Error testing X.com trending detector: {e}")
        return False

@pytest.mark.asyncio
async def test_x_trending_analyzer():
    """Test X.com trending analyzer"""
    print("\n🧪 Testing X.com Trending Analyzer...")

    try:
        analyzer = XTrendingAnalyzer()

        # Test AI coding trends analysis
        print("🤖 Analyzing AI coding trends...")
        ai_trends = analyzer.analyze_ai_coding_trends()
        print(f"Found {len(ai_trends)} AI coding trends")

        for trend in ai_trends[:5]:  # Show top 5
            print(f"  • {trend.topic} - Score: {trend.score:.2f} - Trend: {trend.engagement_trend}")

        # Test software development trends
        print("\n💻 Analyzing software development trends...")
        dev_trends = analyzer.analyze_software_development_trends()
        print(f"Found {len(dev_trends)} software development trends")

        for trend in dev_trends[:5]:  # Show top 5
            print(f"  • {trend.topic} - Score: {trend.score:.2f} - Category: {trend.category}")

        # Test free AI bots trends
        print("\n🆓 Analyzing free AI bot trends...")
        free_ai_trends = analyzer.analyze_free_ai_bots_trends()
        print(f"Found {len(free_ai_trends)} free AI bot trends")

        for trend in free_ai_trends[:5]:  # Show top 5
            print(f"  • {trend.topic} - Score: {trend.score:.2f}")

        return True

    except Exception as e:
        print(f"❌ Error testing X.com trending analyzer: {e}")
        return False

@pytest.mark.asyncio
async def test_search_manager_integration():
    """Test Search Manager with X.com integration"""
    print("\n🧪 Testing Search Manager with X.com Integration...")

    try:
        # Initialize search manager with social media enabled
        manager = SearchManager(enable_social=True, enable_trending=False, enable_ai=False)

        # Test comprehensive trends report
        print("📊 Generating comprehensive trends report...")
        report = await manager.get_comprehensive_trends_report()

        print("✅ Comprehensive trends report generated")
        print(f"Features enabled: {report['features']}")

        if 'x_com_trends' in report:
            x_trends = report['x_com_trends']
            if 'ai_coding' in x_trends:
                ai_trends = x_trends['ai_coding']
                if 'ai_coding_trends' in ai_trends:
                    print(f"AI coding trends found: {len(ai_trends['ai_coding_trends'])}")

        # Test AI coding trends
        print("\n🤖 Getting AI coding trends...")
        ai_trends = await manager.get_ai_coding_trends()

        if 'ai_coding_trends' in ai_trends:
            print(f"Found {len(ai_trends['ai_coding_trends'])} AI coding trends")
            for trend in ai_trends['ai_coding_trends'][:3]:
                print(f"  • {trend.topic} - Score: {trend.score:.2f}")

        # Test software development trends
        print("\n💻 Getting software development trends...")
        dev_trends = await manager.get_software_development_trends()

        if 'software_development_trends' in dev_trends:
            print(f"Found {len(dev_trends['software_development_trends'])} software development trends")
            for trend in dev_trends['software_development_trends'][:3]:
                print(f"  • {trend.topic} - Score: {trend.score:.2f}")

        return True

    except Exception as e:
        print(f"❌ Error testing Search Manager integration: {e}")
        return False

@pytest.mark.asyncio
async def test_search_with_social_trends():
    """Test search with social media trends"""
    print("\n🧪 Testing Search with Social Media Trends...")

    try:
        manager = SearchManager(enable_social=True, enable_trending=False, enable_ai=False)

        # Test search with social trends
        print("🔍 Searching for 'AI coding' with social trends...")
        results = await manager.search_with_social_trends("AI coding", max_results=5)

        print("✅ Search with social trends completed")
        print(f"Search results: {len(results['search_results'].results)}")

        if results['social_trends']:
            social_trends = results['social_trends']
            if 'trending_topics' in social_trends:
                print(f"Social trending topics: {len(social_trends['trending_topics'])}")
            if 'coding_trends' in social_trends:
                print(f"Coding trends: {len(social_trends['coding_trends'])}")

        return True

    except Exception as e:
        print(f"❌ Error testing search with social trends: {e}")
        return False

async def main():
    """Run all tests"""
    print("🚀 Testing X.com Social Media Integration")
    print("=" * 60)
    
    tests = [
        ("X.com Trending Detector", test_x_trending_detector),
        ("X.com Trending Analyzer", test_x_trending_analyzer),
        ("Search Manager Integration", test_search_manager_integration),
        ("Search with Social Trends", test_search_with_social_trends)
    ]
    
    results = []
    for test_name, test_func in tests:
        try:
            result = await test_func()
            results.append((test_name, result))
            status = "✅ PASSED" if result else "❌ FAILED"
            print(f"{status}: {test_name}")
        except Exception as e:
            results.append((test_name, False))
            print(f"❌ FAILED: {test_name} - {e}")
    
    print("\n" + "=" * 60)
    print("📊 Test Results Summary:")
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASSED" if result else "❌ FAILED"
        print(f"  {status}: {test_name}")
    
    print(f"\n🎯 Overall: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed! X.com integration is working correctly.")
    else:
        print("⚠️  Some tests failed. Check the implementation.")
    
    print("\n📝 Note: Some tests may fail if Chrome WebDriver is not installed.")
    print("To install Chrome WebDriver, run: brew install chromedriver")

if __name__ == "__main__":
    asyncio.run(main())
