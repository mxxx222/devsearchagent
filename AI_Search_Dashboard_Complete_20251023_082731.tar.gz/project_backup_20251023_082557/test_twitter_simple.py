#!/usr/bin/env python3
"""
Simple test for Twitter API integration
"""

import os
import sys
import requests
import json

# Add the project root to the Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_twitter_endpoints():
    """Test Twitter API endpoints"""
    base_url = "http://localhost:8080"
    
    print("🧪 Testing Twitter API Endpoints")
    print("=" * 40)
    
    # Test 1: Trending endpoint
    print("1. Testing /api/twitter/trending...")
    try:
        response = requests.get(f"{base_url}/api/twitter/trending?limit=3", timeout=10)
        print(f"   Status: {response.status_code}")
        if response.status_code == 200:
            data = response.json()
            print(f"   ✅ Success: {len(data.get('trends', []))} trends found")
        else:
            print(f"   ❌ Error: {response.text[:100]}...")
    except Exception as e:
        print(f"   ❌ Exception: {e}")
    
    # Test 2: Search endpoint
    print("\n2. Testing /api/twitter/search...")
    try:
        response = requests.get(f"{base_url}/api/twitter/search?q=AI&max_results=3", timeout=10)
        print(f"   Status: {response.status_code}")
        if response.status_code == 200:
            data = response.json()
            print(f"   ✅ Success: {len(data.get('tweets', []))} tweets found")
        else:
            print(f"   ❌ Error: {response.text[:100]}...")
    except Exception as e:
        print(f"   ❌ Exception: {e}")
    
    # Test 3: Analyze endpoint
    print("\n3. Testing /api/twitter/analyze...")
    try:
        response = requests.get(f"{base_url}/api/twitter/analyze?q=AI%20coding", timeout=10)
        print(f"   Status: {response.status_code}")
        if response.status_code == 200:
            data = response.json()
            print(f"   ✅ Success: {len(data.get('trending_topics', []))} topics analyzed")
        else:
            print(f"   ❌ Error: {response.text[:100]}...")
    except Exception as e:
        print(f"   ❌ Exception: {e}")
    
    # Test 4: Check if endpoints exist by testing a non-existent endpoint
    print("\n4. Testing non-existent endpoint...")
    try:
        response = requests.get(f"{base_url}/api/twitter/nonexistent", timeout=5)
        print(f"   Status: {response.status_code}")
        if response.status_code == 404:
            print("   ✅ Expected 404 for non-existent endpoint")
        else:
            print(f"   ⚠️  Unexpected status: {response.status_code}")
    except Exception as e:
        print(f"   ❌ Exception: {e}")

def test_direct_twitter_api():
    """Test Twitter API directly"""
    print("\n🔧 Testing Twitter API Directly")
    print("=" * 40)
    
    try:
        from search.social.twitter_api_v2 import TwitterAPIv2
        
        twitter_api = TwitterAPIv2()
        
        if not twitter_api.bearer_token:
            print("❌ No Twitter Bearer Token found")
            print("   Please set TWITTER_BEARER_TOKEN in config.env")
            return
        
        print("✅ Twitter API initialized successfully")
        
        # Test search
        print("\nTesting tweet search...")
        tweets = twitter_api.search_recent_tweets("AI coding", max_results=3)
        print(f"   Found {len(tweets)} tweets")
        
        # Test trending analysis
        print("\nTesting trending analysis...")
        trends = twitter_api.analyze_trending_topics("AI coding")
        print(f"   Found {len(trends)} trending topics")
        
    except Exception as e:
        print(f"❌ Error testing Twitter API: {e}")

if __name__ == "__main__":
    test_twitter_endpoints()
    test_direct_twitter_api()
