#!/usr/bin/env python3
"""
Test script to verify X.com API integration has been removed
"""

import sys
import os
import pytest

# Add the project root to the path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

def test_x_api_removal():
    """Test that X.com API integration has been removed"""
    print("🧪 Testing X.com API Integration Removal...")

    # Test 1: Check that X.com API files are removed
    x_api_files = [
        "search/social/x_api.py",
        "test_x_api_integration.py",
        "x_api_web_interface.py",
        "X_API_SETUP_GUIDE.md"
    ]

    removed_files = []
    for file_path in x_api_files:
        if not os.path.exists(file_path):
            removed_files.append(file_path)

    print(f"✅ Removed {len(removed_files)} X.com API files:")
    for file_path in removed_files:
        print(f"  • {file_path}")

    # Test 2: Check that X.com API imports are removed
    try:
        from search.config import Config
        print("✅ Configuration module loads correctly")

        # Check that X.com API keys are not in config
        assert not hasattr(Config, 'X_BEARER_TOKEN'), "X_BEARER_TOKEN should be removed from config"
        print("✅ X_BEARER_TOKEN removed from config")

        assert not hasattr(Config, 'X_API_KEY'), "X_API_KEY should be removed from config"
        print("✅ X_API_KEY removed from config")

    except Exception as e:
        print(f"❌ Error loading config: {e}")
        pytest.fail(f"Config loading failed: {e}")

    # Test 3: Check that X.com API dependencies are removed
    try:
        import tweepy
        pytest.fail("tweepy should be removed (X.com API dependency)")
    except ImportError:
        print("✅ tweepy removed (X.com API dependency)")

    try:
        import snscrape
        pytest.fail("snscrape should be removed (X.com API dependency)")
    except ImportError:
        print("✅ snscrape removed (X.com API dependency)")

    # Test 4: Verify that web scraping components still work
    try:
        from search.social.x_trending import XTrendingDetector
        from search.social.x_analyzer import XTrendingAnalyzer
        print("✅ X.com web scraping components still available")
    except Exception as e:
        print(f"❌ Error loading X.com web scraping components: {e}")
        pytest.fail(f"Web scraping components failed to load: {e}")

    assert True

def main():
    """Run the test"""
    print("🚀 Testing X.com API Integration Removal")
    print("=" * 50)
    
    try:
        test_x_api_removal()
        print("\n✅ X.com API integration successfully removed!")
        print("📝 The system now only uses X.com web scraping (no API keys required)")
        print("🌐 Web scraping components are still available for trending topics")
        
    except Exception as e:
        print(f"❌ Error during testing: {e}")

if __name__ == "__main__":
    main()
