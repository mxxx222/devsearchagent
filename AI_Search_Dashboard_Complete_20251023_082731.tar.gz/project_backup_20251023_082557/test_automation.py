#!/usr/bin/env python3
"""
Test script for the topic automation system
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from topic_automation import TopicAutomation
import json

def test_automation():
    """Test the automation system"""
    print("🧪 Testing Topic Automation System")
    print("=" * 50)
    
    # Initialize automation
    automation = TopicAutomation()
    
    # Test individual components
    print("\n1. Testing AI Generation Trigger...")
    ai_success = automation.trigger_ai_generation()
    print(f"   Result: {'✅ Success' if ai_success else '❌ Failed'}")
    
    print("\n2. Testing Twitter Trends Analysis...")
    twitter_trends = automation.analyze_twitter_trends()
    print(f"   Result: {'✅ Success' if twitter_trends else '❌ Failed'}")
    if twitter_trends:
        print(f"   Topics found: {twitter_trends.get('count', 0)}")
    
    print("\n3. Testing Topic Search Trigger...")
    search_success = automation.trigger_topic_search()
    print(f"   Result: {'✅ Success' if search_success else '❌ Failed'}")
    
    print("\n4. Testing Get New Topics...")
    topics_data = automation.get_new_topics()
    print(f"   Result: {'✅ Success' if topics_data else '❌ Failed'}")
    if topics_data:
        recommendations = topics_data.get('recommendations', {}).get('recommendations', [])
        trending = topics_data.get('trending', {}).get('trending', [])
        print(f"   AI Recommendations: {len(recommendations)}")
        print(f"   Trending Topics: {len(trending)}")
    
    print("\n5. Testing Twitter Tweet Search...")
    twitter_tweets = automation.search_twitter_tweets()
    print(f"   Result: {'✅ Success' if twitter_tweets else '❌ Failed'}")
    if twitter_tweets:
        print(f"   Tweets found: {twitter_tweets.get('count', 0)}")
    
    print("\n6. Testing Data Processing...")
    summary = automation.process_topics_data(topics_data, twitter_tweets)
    print(f"   Result: {'✅ Success' if summary else '❌ Failed'}")
    if summary:
        print(f"   Total Topics: {summary.get('totalTopics', 0)}")
        print(f"   AI Recommendations: {summary.get('aiRecommendations', 0)}")
        print(f"   Trending Topics: {summary.get('trendingTopics', 0)}")
    
    print("\n7. Testing Slack Notification...")
    slack_success = automation.send_slack_notification(summary)
    print(f"   Result: {'✅ Success' if slack_success else 'ℹ️ Skipped (no webhook)'}")
    
    print("\n8. Testing Email Notification...")
    email_success = automation.send_email_notification(summary)
    print(f"   Result: {'✅ Success' if email_success else 'ℹ️ Skipped (no SMTP)'}")
    
    print("\n9. Testing Database Save...")
    db_success = automation.save_to_database(summary)
    print(f"   Result: {'✅ Success' if db_success else 'ℹ️ Skipped (no database)'}")
    
    print("\n10. Testing Execution Logging...")
    log_success = automation.log_execution(summary)
    print(f"   Result: {'✅ Success' if log_success else '❌ Failed'}")
    
    print("\n" + "=" * 50)
    print("🎯 Test Summary:")
    
    # Overall success rate
    tests = [
        ai_success,
        bool(twitter_trends),
        search_success,
        bool(topics_data),
        bool(twitter_tweets),
        bool(summary),
        slack_success,
        email_success,
        db_success,
        log_success
    ]
    
    success_count = sum(tests)
    total_tests = len(tests)
    success_rate = (success_count / total_tests) * 100
    
    print(f"✅ Successful: {success_count}/{total_tests} ({success_rate:.1f}%)")
    
    if success_rate >= 80:
        print("🎉 Automation system is working well!")
    elif success_rate >= 60:
        print("⚠️ Automation system is mostly working, some issues detected")
    else:
        print("❌ Automation system has significant issues")
    
    return success_rate >= 60

def test_full_automation():
    """Test the complete automation process"""
    print("\n🚀 Testing Full Automation Process...")
    print("=" * 50)
    
    automation = TopicAutomation()
    success = automation.run_once()
    
    print(f"Full automation result: {'✅ Success' if success else '❌ Failed'}")
    return success

if __name__ == "__main__":
    print("🔧 Topic Automation Test Suite")
    print("=" * 60)
    
    # Test individual components
    component_test = test_automation()
    
    # Test full automation
    full_test = test_full_automation()
    
    print("\n" + "=" * 60)
    print("📊 Final Results:")
    print(f"Component Tests: {'✅ Passed' if component_test else '❌ Failed'}")
    print(f"Full Automation: {'✅ Passed' if full_test else '❌ Failed'}")
    
    if component_test and full_test:
        print("\n🎉 All tests passed! Automation system is ready to use.")
        print("\nTo start the automation scheduler:")
        print("python topic_automation.py")
        print("\nTo run once for testing:")
        print("python topic_automation.py --once")
    else:
        print("\n⚠️ Some tests failed. Please check the logs and fix issues.")
        sys.exit(1)
