#!/usr/bin/env python3
"""
Simple test script for X.com integration without web scraping
"""

import sys
import os
import asyncio
import logging
import pytest
from datetime import datetime

# Add the project root to the path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from search.social.x_trending import XTrendingDetector
from search.social.x_analyzer import XTrendingAnalyzer

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def test_x_trending_detector_basic():
    """Test basic X.com trending detector functionality"""
    print("🧪 Testing X.com Trending Detector (Basic)...")

    try:
        detector = XTrendingDetector()

        # Test keyword detection
        test_text = "GitHub Copilot is revolutionizing AI coding with free alternatives like Cursor AI"
        keywords = detector._extract_keywords_from_tweet(test_text)
        print(f"📊 Extracted keywords: {keywords}")

        # Test coding relevance
        coding_keywords = [kw for kw in keywords if detector._is_coding_related(kw)]
        print(f"🤖 Coding-related keywords: {coding_keywords}")

        # Test categorization
        for keyword in coding_keywords:
            category = detector._categorize_topic(keyword)
            print(f"  • {keyword} -> {category}")

        assert True

    except Exception as e:
        print(f"❌ Error testing X.com trending detector: {e}")
        pytest.fail(f"X.com trending detector test failed: {e}")

def test_x_trending_analyzer_basic():
    """Test basic X.com trending analyzer functionality"""
    print("\n🧪 Testing X.com Trending Analyzer (Basic)...")

    try:
        analyzer = XTrendingAnalyzer()

        # Test mock data analysis
        from search.social.x_trending import XTrendingData

        mock_data = [
            XTrendingData(
                topic="github copilot",
                frequency=15,
                engagement_score=0.8,
                category="ai_coding",
                timestamp=datetime.now()
            ),
            XTrendingData(
                topic="free ai coding assistant",
                frequency=12,
                engagement_score=0.9,
                category="ai_coding",
                timestamp=datetime.now()
            ),
            XTrendingData(
                topic="cursor ai",
                frequency=8,
                engagement_score=0.7,
                category="ai_coding",
                timestamp=datetime.now()
            )
        ]

        # Test analysis
        analysis = analyzer._analyze_topic("github copilot", mock_data)
        if analysis:
            print(f"✅ Analysis successful:")
            print(f"  • Topic: {analysis.topic}")
            print(f"  • Score: {analysis.score:.2f}")
            print(f"  • Category: {analysis.category}")
            print(f"  • Trend: {analysis.engagement_trend}")

        assert True

    except Exception as e:
        print(f"❌ Error testing X.com trending analyzer: {e}")
        pytest.fail(f"X.com trending analyzer test failed: {e}")

def test_search_manager_basic():
    """Test basic Search Manager functionality"""
    print("\n🧪 Testing Search Manager (Basic)...")

    try:
        from search.manager import SearchManager

        # Initialize with social media enabled
        manager = SearchManager(enable_social=True, enable_trending=False, enable_ai=False)

        print("✅ Search Manager initialized successfully")
        print(f"  • Social media enabled: {manager.enable_social}")
        print(f"  • X.com detector available: {manager.x_trending_detector is not None}")
        print(f"  • X.com analyzer available: {manager.x_trending_analyzer is not None}")

        assert True

    except Exception as e:
        print(f"❌ Error testing Search Manager: {e}")
        pytest.fail(f"Search Manager test failed: {e}")

def main():
    """Run all basic tests"""
    print("🚀 Testing X.com Integration (Basic Tests)")
    print("=" * 50)
    
    tests = [
        ("X.com Trending Detector (Basic)", test_x_trending_detector_basic),
        ("X.com Trending Analyzer (Basic)", test_x_trending_analyzer_basic),
        ("Search Manager (Basic)", test_search_manager_basic)
    ]
    
    results = []
    for test_name, test_func in tests:
        try:
            result = test_func()
            results.append((test_name, result))
            status = "✅ PASSED" if result else "❌ FAILED"
            print(f"{status}: {test_name}")
        except Exception as e:
            results.append((test_name, False))
            print(f"❌ FAILED: {test_name} - {e}")
    
    print("\n" + "=" * 50)
    print("📊 Test Results Summary:")
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASSED" if result else "❌ FAILED"
        print(f"  {status}: {test_name}")
    
    print(f"\n🎯 Overall: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All basic tests passed! X.com integration is working correctly.")
        print("\n📝 Next steps:")
        print("  1. Install Chrome WebDriver: brew install chromedriver")
        print("  2. Run the full test: python test_x_integration.py")
        print("  3. Start the web interface: python x_trends_web_interface.py")
    else:
        print("⚠️  Some tests failed. Check the implementation.")

if __name__ == "__main__":
    main()
