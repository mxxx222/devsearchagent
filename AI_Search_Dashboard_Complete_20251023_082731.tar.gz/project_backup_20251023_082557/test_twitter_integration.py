#!/usr/bin/env python3
"""
Test script for Twitter API v2 integration
"""

import os
import sys
import asyncio
from datetime import datetime

# Add the project root to the Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from search.social.twitter_api_v2 import TwitterAPIv2
from search.social import XAnalyzer

def test_twitter_api():
    """Test Twitter API v2 functionality"""
    print("🐦 Testing Twitter API v2 Integration")
    print("=" * 50)
    
    # Initialize Twitter API
    twitter_api = TwitterAPIv2()
    
    # Check if bearer token is available
    if not twitter_api.bearer_token:
        print("❌ No Twitter Bearer Token found. Please set TWITTER_BEARER_TOKEN in config.env")
        print("   Get your Bearer Token from: https://developer.twitter.com/en/portal/dashboard")
        return False
    
    print("✅ Twitter Bearer Token found")
    
    # Test trending topics analysis
    print("\n📊 Testing trending topics analysis...")
    try:
        trending_topics = twitter_api.analyze_trending_topics("AI coding OR programming OR software development")
        if trending_topics:
            print(f"✅ Found {len(trending_topics)} trending topics:")
            for i, topic in enumerate(trending_topics[:5], 1):
                print(f"   {i}. {topic['topic']} (Frequency: {topic['frequency']}, Engagement: {topic['avg_engagement']:.1f})")
        else:
            print("⚠️  No trending topics found (this might be normal if API rate limits are reached)")
    except Exception as e:
        print(f"❌ Error analyzing trending topics: {e}")
    
    # Test tweet search
    print("\n🔍 Testing tweet search...")
    try:
        tweets = twitter_api.search_recent_tweets("AI coding", max_results=5)
        if tweets:
            print(f"✅ Found {len(tweets)} tweets:")
            for i, tweet in enumerate(tweets[:3], 1):
                print(f"   {i}. @{tweet['author_username']}: {tweet['text'][:100]}...")
        else:
            print("⚠️  No tweets found (this might be normal if API rate limits are reached)")
    except Exception as e:
        print(f"❌ Error searching tweets: {e}")
    
    return True

def test_x_analyzer():
    """Test XAnalyzer wrapper"""
    print("\n🔧 Testing XAnalyzer wrapper...")
    try:
        analyzer = XAnalyzer()
        print("✅ XAnalyzer initialized successfully")
        
        # Test trending topics (this will try API first, then fallback to web scraping)
        print("📊 Testing trending topics via XAnalyzer...")
        trending = analyzer.get_trending_topics_api(limit=5)
        if trending:
            print(f"✅ Found {len(trending)} trending topics via API:")
            for i, trend in enumerate(trending[:3], 1):
                print(f"   {i}. {trend['name']} (Volume: {trend.get('tweet_volume', 'N/A')})")
        else:
            print("⚠️  No trending topics found via API")
            
    except Exception as e:
        print(f"❌ Error testing XAnalyzer: {e}")

def test_api_endpoints():
    """Test the new Twitter API endpoints"""
    print("\n🌐 Testing Twitter API endpoints...")
    import requests
    
    base_url = "http://localhost:8080"
    
    # Test trending endpoint
    try:
        response = requests.get(f"{base_url}/api/twitter/trending?limit=5", timeout=10)
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Trending endpoint working: {len(data.get('trends', []))} trends found")
        else:
            print(f"⚠️  Trending endpoint returned status {response.status_code}")
    except Exception as e:
        print(f"❌ Error testing trending endpoint: {e}")
    
    # Test search endpoint
    try:
        response = requests.get(f"{base_url}/api/twitter/search?q=AI%20coding&max_results=3", timeout=10)
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Search endpoint working: {len(data.get('tweets', []))} tweets found")
        else:
            print(f"⚠️  Search endpoint returned status {response.status_code}")
    except Exception as e:
        print(f"❌ Error testing search endpoint: {e}")
    
    # Test analyze endpoint
    try:
        response = requests.get(f"{base_url}/api/twitter/analyze?q=AI%20coding", timeout=10)
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Analyze endpoint working: {len(data.get('trending_topics', []))} topics analyzed")
        else:
            print(f"⚠️  Analyze endpoint returned status {response.status_code}")
    except Exception as e:
        print(f"❌ Error testing analyze endpoint: {e}")

def main():
    """Main test function"""
    print("🚀 Twitter API v2 Integration Test")
    print("=" * 60)
    print(f"Test started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    # Load environment variables
    try:
        from dotenv import load_dotenv
        load_dotenv('config.env')
        print("✅ Environment variables loaded from config.env")
    except ImportError:
        print("⚠️  python-dotenv not installed, using system environment variables")
    except Exception as e:
        print(f"⚠️  Could not load config.env: {e}")
    
    # Run tests
    test_twitter_api()
    test_x_analyzer()
    test_api_endpoints()
    
    print("\n" + "=" * 60)
    print("✅ Twitter API v2 integration test completed!")
    print("\nNext steps:")
    print("1. Get Twitter API credentials from: https://developer.twitter.com/en/portal/dashboard")
    print("2. Update config.env with your Twitter API credentials")
    print("3. Restart the server to use Twitter API functionality")

if __name__ == "__main__":
    main()
