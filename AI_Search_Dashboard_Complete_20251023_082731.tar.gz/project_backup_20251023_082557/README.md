# Search Dashboard

A modern web dashboard for search analytics, trending topics, and AI-powered recommendations.

## Features

- **Search Interface**: Perform searches and view results in real-time
- **Trending Topics**: Visual chart and list of trending topics with scores
- **AI Recommendations**: Confidence-based query recommendations
- **Responsive Design**: Works on desktop and mobile devices
- **Real-time Updates**: Auto-refreshing data every 30 seconds

## Quick Start

1. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

2. **Run the application:**
   ```bash
   python run.py
   ```
   Or directly:
   ```bash
   python app.py
   ```

3. **Open your browser:**
   Navigate to `http://localhost:5000`

## Project Structure

```
├── app.py                 # Main Flask application
├── run.py                 # Run script with enhanced logging
├── requirements.txt       # Python dependencies
├── templates/
│   └── dashboard.html     # Main dashboard template
└── static/
    ├── css/
    │   └── style.css      # Dashboard styling
    └── js/
        └── dashboard.js   # Frontend JavaScript
```

## API Endpoints

- `GET /` - Main dashboard
- `POST /search` - Perform search query
- `GET /api/trending` - Get trending data
- `GET /api/recommendations` - Get AI recommendations

## Technologies Used

- **Backend**: Flask (Python)
- **Frontend**: HTML5, CSS3, JavaScript
- **Charts**: Chart.js
- **Styling**: Custom CSS with gradients and animations

## Development

The application uses mock data for demonstration. To integrate with real search engines, trending APIs, or AI services, modify the mock data in `app.py` with actual API calls.

## License

MIT License