#!/usr/bin/env python3
"""
Direct test of Twitter API endpoints
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from flask import Flask
from search.social.twitter_api_v2 import TwitterAPIv2

def test_twitter_endpoints_directly():
    """Test Twitter API endpoints directly"""
    print("🧪 Testing Twitter API Endpoints Directly")
    print("=" * 50)
    
    # Create a test Flask app
    app = Flask(__name__)
    
    # Initialize Twitter API
    twitter_api = TwitterAPIv2()
    
    # Test Twitter API initialization
    print(f"Twitter API initialized: {twitter_api is not None}")
    print(f"Bearer token available: {bool(twitter_api.bearer_token)}")
    
    # Test trending topics
    print("\nTesting trending topics...")
    try:
        trends = twitter_api.get_trending_topics(woeid=1, limit=5)
        print(f"Found {len(trends)} trending topics")
        for i, trend in enumerate(trends[:3], 1):
            print(f"  {i}. {trend['name']}")
    except Exception as e:
        print(f"Error getting trending topics: {e}")
    
    # Test tweet search
    print("\nTesting tweet search...")
    try:
        tweets = twitter_api.search_recent_tweets("AI coding", max_results=3)
        print(f"Found {len(tweets)} tweets")
        for i, tweet in enumerate(tweets[:2], 1):
            print(f"  {i}. @{tweet.get('author_username', 'unknown')}: {tweet['text'][:50]}...")
    except Exception as e:
        print(f"Error searching tweets: {e}")
    
    # Test trending analysis
    print("\nTesting trending analysis...")
    try:
        topics = twitter_api.analyze_trending_topics("AI coding OR programming")
        print(f"Found {len(topics)} trending topics")
        for i, topic in enumerate(topics[:3], 1):
            print(f"  {i}. {topic['topic']} (Frequency: {topic['frequency']})")
    except Exception as e:
        print(f"Error analyzing trending topics: {e}")

if __name__ == "__main__":
    test_twitter_endpoints_directly()
